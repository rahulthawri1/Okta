package com.okta.app.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.okta.app.config.SwaggerConfig;
import com.okta.sdk.client.Client;
import com.okta.sdk.resource.application.ApplicationList;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class ApplicationController {
	private final Log logger = LogFactory.getLog(ApplicationController.class);
	@Autowired
	public Client client;
	// URIs-Link :- http://localhost:8080/applications
	@GetMapping("/applications")
	public ApplicationList getApplications() {
		logger.debug("Getting applications: {} " );
		return client.listApplications();
	}
}
