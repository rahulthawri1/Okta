package com.okta.app.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.okta.sdk.client.Client;
import com.okta.sdk.resource.Resource;
import com.okta.sdk.resource.user.User;
import com.okta.sdk.resource.user.UserBuilder;
import com.okta.sdk.resource.user.UserList;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class UserController {
	private final Log logger = LogFactory.getLog(UserController.class);
	@Autowired
	public Client client;
	private String href;
	// URIs-Link :- http://localhost:8080/users
	@GetMapping("/users")
	public UserList getUsers() {
		logger.debug("Getting users: {} " );
		return client.listUsers();
	}
	// URIs-Link :- http://localhost:8080/user?query=ashishthawri%40gmail.com
	@GetMapping("/user")
	public UserList searchUserByEmail(@RequestParam String query) {
		logger.debug("Getting user searchUserByEmail: {} " );
		return client.listUsers(query, null, null, null, null);
	}
	// URIs-Link :- http://localhost:8080/createUser
	@GetMapping("/createUser")
	public User createUser() {
		char[] tempPassword = { 'P', 'a', '$', '$', 'w', '0', 'r', 'd' };
		User user = UserBuilder.instance().setEmail("rahulthawri1@gmail.com").setFirstName("Rahul")
				.setLastName("Thawri").setPassword(tempPassword).setActive(true).buildAndCreate(client);
		logger.debug("Creating user : {} createUser()" );
		return user;
	}
	
}
