package com.okta.app.security.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.okta.spring.boot.oauth.Okta;

/**
 * @author rahuldigambart
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	private final Log logger = LogFactory.getLog(SecurityConfiguration.class);
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		logger.debug("Using default configure(HttpSecurity) !!!***!!!");
		httpSecurity.
		authorizeRequests()
		.anyRequest().
		authenticated().
		and().
		oauth2ResourceServer().
		jwt();
		
	}
}
