package com.okta.app.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.okta.app.security.config.SecurityConfiguration;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class WebController {
	private final Log logger = LogFactory.getLog(WebController.class);
	// URIs-Link :- http://localhost:8080/web
	@GetMapping("/web")
	public String home(@AuthenticationPrincipal OidcUser oidcUser) {
		logger.info("home method started !!!***!!!" );
		return "Welcome to Okta SSO Page, " + "Full Name :-" + oidcUser.getFullName() + "!!!***!!!"
				+ "Access Token :-" + oidcUser.getAccessTokenHash() + "!!!***!!!" + "Id Token :-"
				+ oidcUser.getIdToken() + "!!!***!!!";
		
	}
	// URIs-Link :- http://localhost:8080/attributes
	@GetMapping("/attributes")
	public String attributes(@AuthenticationPrincipal OidcUser oidcUser) {
		logger.debug("Getting attributes: {} " + oidcUser.getAttributes().toString() );
		return oidcUser.getAttributes().toString();
	}
	// URIs-Link :- http://localhost:8080/authorities
	@GetMapping("/authorities")
	public String authorities(@AuthenticationPrincipal OidcUser oidcUser) {
		logger.debug("Getting authorities: {} " + oidcUser.getAuthorities().toString());
		return oidcUser.getAuthorities().toString();
	}
}
