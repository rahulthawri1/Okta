package com.okta.app.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author rahuldigambart
 *
 */

@RestController
public class OktaController {
	private final Log logger = LogFactory.getLog(OktaController.class);
	// URIs-Link :- http://localhost:8080/okta
	@GetMapping("/okta")
	public String home(@AuthenticationPrincipal OidcUser user) {
		logger.debug("User FullName : {} " + user.getFullName() );
		return "Welcome to Okta SSO Page, " + user.getFullName() + "!";
	}
}
