package com.okta.app.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.okta.app.security.config.SecurityConfiguration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author rahuldigambart
 *
 */
@Configuration
//Enable Swagger
@EnableSwagger2
public class SwaggerConfig {
	private final Log logger = LogFactory.getLog(SwaggerConfig.class);
	// URIs Link :- http://localhost:8080/v2/api-docs
	// URIs Link :- http://localhost:8080/swagger-ui.html#! ***-HTML look-***
	// creating bean
	@Bean
	public Docket api() {
		logger.debug("Using default api(Docket(EnableSwagger2) : {} ");
		// creating instance of Docket class that accepts parameter DocumentationType
		return new Docket(DocumentationType.SWAGGER_2)
		.select()
        .apis(RequestHandlerSelectors.any())
        .paths(PathSelectors.any())
        .build();
        
	}

	// bean- docket
	// swagger 2
	// All the paths
	// all the APIs
}
